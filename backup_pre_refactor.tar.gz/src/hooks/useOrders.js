import { useEffect, useState } from 'react';
import { fetchPedidos as fetchPedidosAPI, upsertPedidos } from '../api/orderService';

// Hook to manage a paginated list of orders with optional filters
export const useOrders = (initialParams = {}) => {
  const [pedidos, setPedidos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(initialParams.page || 1);
  const [perPage] = useState(initialParams.perPage || 50);

  const load = async (params = {}) => {
    setLoading(true);
    try {
      const result = await fetchPedidosAPI({ ...initialParams, ...params, page, perPage });
      if (result && result.data) setPedidos(result.data);
    } catch (e) {
      // Silently swallow; UI should handle errors via toasts in consuming components
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialParams, page]);

  return {
    pedidos,
    loading,
    page,
    setPage,
    reload: () => load(),
    upsertPedidos: async (ped) => upsertPedidos(ped),
  };
};
