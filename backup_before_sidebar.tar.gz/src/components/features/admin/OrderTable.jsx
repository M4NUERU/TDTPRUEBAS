import React from 'react';
import { Package, Truck, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { Badge } from '../../ui/Badge';

export const OrderTable = ({ orders }) => {
    return (
        <div className="bg-[var(--bg-card)] rounded-[2.5rem] border border-[var(--border-ui)] overflow-hidden shadow-sm mt-8">
            <div className="p-6 border-b border-[var(--border-ui)] flex justify-between items-center">
                <h2 className="text-xl font-black uppercase text-[var(--text-main)] tracking-tight flex items-center gap-2">
                    <Package size={20} className="text-blue-600" />
                    Gestión de Pedidos
                </h2>
                <Badge variant="outline">{orders.length} Registros</Badge>
            </div>
            <div className="overflow-x-auto max-h-[500px] scrollbar-thin">
                <table className="w-full text-left border-collapse min-w-[1000px]">
                    <thead className="sticky top-0 bg-[var(--bg-input)] z-10">
                        <tr className="border-b border-[var(--border-ui)]">
                            <th className="px-6 py-4 text-[9px] font-black uppercase text-[var(--text-muted)] tracking-widest">Estado</th>
                            <th className="px-6 py-4 text-[9px] font-black uppercase text-[var(--text-muted)] tracking-widest">Orden / Cliente</th>
                            <th className="px-6 py-4 text-[9px] font-black uppercase text-[var(--text-muted)] tracking-widest w-64">Producto</th>
                            <th className="px-6 py-4 text-[9px] font-black uppercase text-[var(--text-muted)] tracking-widest text-center">Cant.</th>
                            <th className="px-6 py-4 text-[9px] font-black uppercase text-[var(--text-muted)] tracking-widest">Logística</th>
                            <th className="px-6 py-4 text-[9px] font-black uppercase text-[var(--text-muted)] tracking-widest">Fechas</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--border-ui)]">
                        {orders.map(order => (
                            <tr key={order.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                                <td className="px-6 py-4">
                                    <Badge variant={
                                        order.estado === 'TERMINADO' ? 'success' :
                                            order.estado === 'ENVIADO' ? 'info' :
                                                order.estado === 'PENDIENTE' ? 'warning' : 'default'
                                    }>
                                        {order.estado}
                                    </Badge>
                                </td>
                                <td className="px-6 py-4">
                                    <div>
                                        <p className="font-black text-xs text-blue-600 uppercase tracking-tight">OC {order.orden_compra}</p>
                                        <p className="text-[9px] font-bold text-[var(--text-muted)] uppercase mt-0.5">{order.cliente}</p>
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    <p className="font-bold text-[10px] text-[var(--text-main)] uppercase leading-tight line-clamp-2" title={order.producto}>
                                        {order.producto}
                                    </p>
                                </td>
                                <td className="px-6 py-4 text-center">
                                    <span className="font-black text-xs text-[var(--text-main)] bg-[var(--bg-input)] px-2 py-1 rounded-lg">
                                        {order.cantidad}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    <div className="flex flex-col gap-1">
                                        {order.transportadora ? (
                                            <div className="flex items-center gap-1.5">
                                                <Truck size={12} className="text-blue-500" />
                                                <span className="text-[9px] font-bold uppercase text-[var(--text-main)]">{order.transportadora}</span>
                                            </div>
                                        ) : <span className="text-[9px] text-[var(--text-muted)] italic">-</span>}

                                        {order.guia_transporte && (
                                            <span className="text-[8px] font-mono bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded text-slate-500 w-fit">
                                                {order.guia_transporte}
                                            </span>
                                        )}
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    <div className="flex flex-col gap-1">
                                        <span className="text-[9px] text-[var(--text-muted)] flex items-center gap-1">
                                            <Clock size={10} /> Ing: {order.fecha_ingreso || '-'}
                                        </span>
                                        {order.fecha_despacho && (
                                            <span className="text-[9px] text-blue-500 font-bold flex items-center gap-1">
                                                <CheckCircle2 size={10} /> Des: {order.fecha_despacho}
                                            </span>
                                        )}
                                    </div>
                                </td>
                            </tr>
                        ))}
                        {orders.length === 0 && (
                            <tr>
                                <td colSpan="6" className="py-20 text-center text-[var(--text-muted)] opacity-40">
                                    <AlertCircle size={32} className="mx-auto mb-2" />
                                    <p className="text-[9px] font-black uppercase">No hay pedidos registrados</p>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
