import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../store/authStore';
import { useAdmin } from '../hooks/useAdmin';
import { useOrders } from '../hooks/useOrders';
import { ShieldCheck, Plus, RefreshCw, Layers, Users, AlertTriangle, Clock } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { DashboardStats } from '../components/features/admin/DashboardStats';
import { UserTable } from '../components/features/admin/UserTable';
// Note: UserModal logic would be similar to MaterialModal, keeping it inline or next extraction task if complex. 
// For this pass, I'll keep the Modal simple or assume extracting it next if it's large.
// Given Admin.jsx was HUGE, let's extract the UserModal too for completeness.

import { OrderTable } from '../components/features/admin/OrderTable';
import { UserModal } from '../components/features/admin/UserModal';

const Admin = () => {
    // Auth
    const user = useAuthStore((state) => state.user);
    const isSuperAdmin = user?.rol === 'ADMIN';

    // Logic
    const { users, stats, loading: adminLoading, fetchUsers, fetchStats, saveUser, deleteUser, resetPassword } = useAdmin();
    // Fetch all orders for the admin dashboard, without status filter (null means all in our new useOrders logic? No, useOrders takes status. Let's create a special mode or fetch all.)
    // Note: useOrders currently fetches by status. Let's start with all PENDING for visibility or modify useOrders.
    // Actually, Despachadores want to see details. Let's fetch all relevant ones.
    const [allOrders, setAllOrders] = useState([]);

    // Quick fix: reuse useOrders but we need a way to get ALL.
    // Or just import supabase here for the specific "All Orders" query if useOrders is too specific.
    // Let's modify useOrders slightly to accept null for "ALL"? 
    // For now, let's just use the 'PENDIENTE' one as a base and maybe fix it later, or better:
    // Let's fetch ALL orders for the "Zone of Pedidos".

    // We can use a direct useEffect here for simplicity since useOrders is tailored for Despacho flow (specific statuses)
    // Or instantiate useOrders multiple times? No.
    // Let's add a "view mode" to this dashboard.

    const { orders: pendingOrders, fetchOrders: refreshPending } = useOrders('PENDIENTE');
    const { orders: dispatchedOrders, fetchOrders: refreshDispatched } = useOrders('ENVIADO');

    // Combine for display or just show pending by default? User said "zona de pedidos", usually implies everything or management.
    // Let's show Pending by default but allow switching.
    const [orderFilter, setOrderFilter] = useState('PENDIENTE');

    // UI
    const [showModal, setShowModal] = useState(false);
    const [editingUser, setEditingUser] = useState(null);

    const handleEdit = (user) => {
        setEditingUser(user);
        setShowModal(true);
    };

    const handleAddNew = () => {
        setEditingUser(null);
        setShowModal(true);
    };

    const handleRefresh = () => {
        if (isSuperAdmin) {
            fetchUsers();
            fetchStats();
        }
        refreshPending();
        refreshDispatched();
    };

    // Stats Config
    const statCards = [
        { label: 'Pedidos Totales', value: stats.scanned, icon: Layers, color: 'bg-blue-500' },
        { label: 'Pendientes', value: stats.pending, icon: Clock, color: 'bg-orange-500' },
        { label: 'Personal', value: stats.staff, icon: Users, color: 'bg-emerald-500' },
        { label: 'Stock Bajo', value: stats.lowStock, icon: AlertTriangle, color: 'bg-red-500' }
    ];

    return (
        <div className="min-h-screen bg-[var(--bg-main)] transition-colors duration-200">
            {/* Header */}
            <div className="bg-[var(--bg-card)] border-b border-[var(--border-ui)] px-4 py-6 sticky top-0 z-30">
                <div className="max-w-[98%] mx-auto flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-900 dark:bg-white rounded-xl text-white dark:text-slate-900">
                            <ShieldCheck size={24} />
                        </div>
                        <h1 className="text-2xl font-black tracking-tighter uppercase dark:text-white">PANEL DE CONTROL</h1>
                    </div>
                    <div className="flex gap-2">
                        <Button variant="ghost" onClick={handleRefresh} loading={adminLoading} size="icon">
                            <RefreshCw size={20} />
                        </Button>
                        {isSuperAdmin && (
                            <Button onClick={handleAddNew} icon={Plus}>
                                NUEVO USUARIO
                            </Button>
                        )}
                    </div>
                </div>
            </div>

            <main className="max-w-[98%] mx-auto p-4 sm:p-8">
                {isSuperAdmin && <DashboardStats stats={statCards} loading={adminLoading} />}

                {/* Orders Section - Visible to Despachadores too */}
                <div className="mb-8">
                    <div className="flex gap-2 mb-4">
                        <Button
                            variant={orderFilter === 'PENDIENTE' ? 'primary' : 'ghost'}
                            onClick={() => setOrderFilter('PENDIENTE')}
                            size="sm"
                        >
                            Pendientes
                        </Button>
                        <Button
                            variant={orderFilter === 'ENVIADO' ? 'primary' : 'ghost'}
                            onClick={() => setOrderFilter('ENVIADO')}
                            size="sm"
                        >
                            Enviados / Historial
                        </Button>
                        <Button
                            variant={orderFilter === 'TERMINADO' ? 'primary' : 'ghost'}
                            onClick={() => setOrderFilter('TERMINADO')}
                            size="sm"
                        >
                            En Despacho
                        </Button>
                    </div>

                    {/* We need the data for the selected filter. 
                       The basic useOrders hook was fixed to one status.
                       Let's do a quick hack: instantiate 3 hooks is inefficient but safe for now, 
                       or better: let's use a "DynamicOrderTable" wrapper.
                       For speed, I will map the filter to the data I have.
                   */}
                    {orderFilter === 'PENDIENTE' && <OrderTable orders={pendingOrders} />}
                    {orderFilter === 'ENVIADO' && <OrderTable orders={dispatchedOrders} />}
                    {orderFilter === 'TERMINADO' && (
                        // We need another hook instance or reuse
                        <DynamicOrderList status="TERMINADO" />
                    )}
                </div>

                {/* Users Section - Only Admin */}
                {isSuperAdmin && (
                    <>
                        <h2 className="text-xl font-black uppercase text-[var(--text-main)] mb-4 tracking-tight flex items-center gap-2 mt-12">
                            <Users size={20} className="text-blue-600" />
                            Gestión de Usuarios
                        </h2>

                        <UserTable
                            users={users}
                            onEdit={handleEdit}
                            onDelete={deleteUser}
                            onResetPassword={(u) => {
                                const newPin = prompt('Nuevo PIN de 4 dígitos:');
                                if (newPin && newPin.length === 4) resetPassword(u.id, newPin);
                            }}
                        />
                    </>
                )}
            </main>

            <UserModal
                isOpen={showModal}
                onClose={() => setShowModal(false)}
                onSave={saveUser}
                editingUser={editingUser}
            />
        </div>
    );
};

// Helper component to fetch on demand
const DynamicOrderList = ({ status }) => {
    const { orders } = useOrders(status);
    return <OrderTable orders={orders} />;
};

export default Admin;
